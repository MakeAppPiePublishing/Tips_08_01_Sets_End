struct Pizza{
    let authenticCheese: Set = ["Bufalo","Fior de late","Gorgonzola","Mozzarella","Parmigiano"]
    let authenticIngredients: Set = ["Basil","Peppers","Tomatoes", "Basil", "Oregano"]
    enum Crust{
        case thin,thick,pan,lavosh,potPie
    }
    var crust : Crust
    var cheeses: Set<String>
    var toppings: Set<String>
    
}

let margherita = Pizza(crust: .thin, cheeses: ["Mozzarella"], toppings: ["Basil","Tomatoes","Parmigiano","Oil"])
let margheritaDoc = Pizza(crust: .thin, cheeses: ["Bufala"], toppings: ["Basil","Tomatoes","Parmigiano","Oil"])
let chicago = Pizza(crust: .pan, cheeses: ["Mozzarella"], toppings: ["Pizza Sauce","Sausage"])
let quattroFormaggi = Pizza(crust: .thin, cheeses: ["Fontina","Gorgonzola","Mozzarella","Parmigiano"], toppings: ["Crushed Tomatoes","Basil","Oil"])


for cheese in quattroFormaggi.cheeses.sorted(){
    print(cheese)
}


let toppings: Set = ["Crushed Tomatoes","Basil","Oil","Chicken","BBQ Sauce","Red Onions","Parmigiano", "Peppernoi","Prociutto","Pineapple","Canadian Bacon"]

chicago.toppings.contains("Sausage")
quattroFormaggi.toppings.contains("Sausage")

margheritaDoc.toppings.isSubset(of: toppings)
margheritaDoc.toppings.subtracting(toppings)

margheritaDoc.toppings.intersection(margheritaDoc.authenticCheese).isEmpty


let cheeses =  quattroFormaggi.cheeses.union(margheritaDoc.cheeses)
cheeses.intersection(quattroFormaggi.authenticCheese)

cheeses.symmetricDifference(quattroFormaggi.authenticCheese)

